import React from 'react';
import {
  AbsoluteFill, Audio, interpolate, Sequence, spring, staticFile,
  useCurrentFrame, useVideoConfig
} from 'remotion';

const C = {
  bg: '#030711', blue: '#55C8FF', cyan: '#9BEAFF',
  white: '#F4FAFF', muted: '#91A7BA'
};

const scenes = [
  {from:0, dur:180, title:'YA GELECEK…', sub:'DÜŞÜNDÜĞÜNDEN DAHA YAKINSA?', kind:'orb'},
  {from:180, dur:240, title:'DÜŞÜN.', sub:'SINIRLARI ZORLA.', kind:'interface'},
  {from:420, dur:330, title:'ÜRET.', sub:'HAYALLERİNİ GERÇEĞE DÖNÜŞTÜR.', kind:'human'},
  {from:750, dur:270, title:'KEŞFET.', sub:'YARININ DÜNYASINI BUGÜNDEN YAŞA.', kind:'world'},
  {from:1020, dur:180, title:'NOVA AI', sub:'GELECEK, ARTIK SENİN ELLERİNDE.', kind:'final'}
];

const Glow: React.FC<{frame:number; kind:string}> = ({frame, kind}) => {
  const pulse = 0.82 + Math.sin(frame / 13) * 0.09;
  return (
    <div style={{
      position:'absolute', width: kind==='world' ? 760 : 560,
      height: kind==='world' ? 760 : 560, borderRadius:'50%',
      left:'50%', top:'43%', transform:`translate(-50%,-50%) scale(${pulse})`,
      background:'radial-gradient(circle, rgba(37,161,255,.26) 0%, rgba(15,89,170,.13) 34%, rgba(0,0,0,0) 70%)',
      filter:'blur(8px)'
    }}/>
  );
};

const ParticleField: React.FC<{frame:number}> = ({frame}) => (
  <div style={{position:'absolute', inset:0, overflow:'hidden'}}>
    {Array.from({length:42}, (_,i) => {
      const x = (i*137.5)%100;
      const y = (i*71.3)%100;
      const drift = (frame*(0.12+(i%4)*0.035)+i*17)%120;
      return <div key={i} style={{
        position:'absolute', left:`${x}%`, top:`${(y-drift+120)%100}%`,
        width:i%7===0?5:2, height:i%7===0?5:2, borderRadius:99,
        background:i%3===0?C.cyan:C.blue, opacity:.25+(i%5)*.1,
        boxShadow:'0 0 12px rgba(85,200,255,.9)'
      }}/>;
    })}
  </div>
);

const Visual: React.FC<{kind:string; frame:number}> = ({kind,frame}) => {
  const {fps} = useVideoConfig();
  const t = frame/fps;
  if (kind==='interface') return (
    <div style={{position:'absolute', inset:0, display:'grid', placeItems:'center'}}>
      {[0,1,2].map((n)=><div key={n} style={{
        position:'absolute', width:460+n*130, height:460+n*130, border:'1px solid rgba(100,205,255,.35)',
        borderRadius:'50%', transform:`rotate(${t*(n%2?18:-22)}deg) scale(${1+n*.05})`,
        boxShadow:'0 0 35px rgba(45,157,255,.08)'
      }}/>)}
      <div style={{fontSize:180, color:C.cyan, textShadow:'0 0 55px #168bff'}}>✧</div>
      <div style={{position:'absolute', top:'28%', width:650, height:2, background:'linear-gradient(90deg,transparent,#63d8ff,transparent)'}}/>
      <div style={{position:'absolute', top:'70%', width:650, height:2, background:'linear-gradient(90deg,transparent,#63d8ff,transparent)'}}/>
    </div>
  );
  if (kind==='human') return (
    <div style={{position:'absolute', left:'50%', top:'43%', transform:'translate(-50%,-50%)', width:500, height:700}}>
      <div style={{position:'absolute', left:'50%', top:0, width:170, height:170, borderRadius:'50%', transform:'translateX(-50%)', background:'radial-gradient(circle at 35% 30%,#d6eaff,#42627f 60%,#101a2c)', boxShadow:'0 0 90px rgba(49,160,255,.3)'}}/>
      <div style={{position:'absolute', left:'50%', top:155, width:420, height:520, transform:'translateX(-50%)', borderRadius:'48% 48% 12% 12%', background:'linear-gradient(110deg,#101d31,#34516d 48%,#0b1424)', clipPath:'polygon(28% 0,72% 0,100% 100%,0 100%)'}}/>
      <div style={{position:'absolute', left:'50%', top:280, width:560, height:2, transform:'translateX(-50%)', background:'linear-gradient(90deg,transparent,#70dfff,transparent)', boxShadow:'0 0 28px #55c8ff'}}/>
    </div>
  );
  if (kind==='world') return (
    <div style={{position:'absolute', left:'50%', top:'43%', transform:'translate(-50%,-50%)', width:620, height:620, borderRadius:'50%', background:'radial-gradient(circle at 35% 30%,#b2f4ff 0%,#238ed4 16%,#102d67 48%,#050b1b 72%)', boxShadow:'0 0 100px rgba(31,151,255,.5), inset -35px -25px 70px #020611'}}>
      <div style={{position:'absolute', inset:30, borderRadius:'50%', border:'2px solid rgba(151,230,255,.35)', transform:`rotate(${t*12}deg) scaleX(.38)`}}/>
    </div>
  );
  return <div style={{position:'absolute', left:'50%', top:'42%', transform:'translate(-50%,-50%)', width:460, height:460, borderRadius:'50%', background:'radial-gradient(circle at 35% 30%,#e6fbff 0%,#54caff 12%,#1263bd 38%,#07152c 70%)', boxShadow:'0 0 110px rgba(42,157,255,.55), inset -30px -30px 70px #020611'}}/>;
};

const Scene: React.FC<{scene:typeof scenes[number]}> = ({scene}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const local = frame-scene.from;
  const enter = spring({frame:local, fps, config:{damping:18, stiffness:90}});
  const opacity = interpolate(local,[0,18,scene.dur-18,scene.dur],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  const y = interpolate(enter,[0,1],[65,0]);
  const zoom = interpolate(local,[0,scene.dur],[.88,1.12],{extrapolateRight:'clamp'});
  return (
    <AbsoluteFill style={{background:C.bg, opacity, overflow:'hidden'}}>
      <div style={{position:'absolute', inset:0, background:'radial-gradient(ellipse at 50% 43%,#10233e 0%,#050c19 45%,#02050b 100%)'}}/>
      <ParticleField frame={local}/>
      <Glow frame={local} kind={scene.kind}/>
      <div style={{transform:`scale(${zoom})`}}><Visual kind={scene.kind} frame={local}/></div>
      <div style={{position:'absolute', left:70, right:70, bottom:250, textAlign:'center', transform:`translateY(${y}px)`}}>
        <div style={{fontFamily:'Arial, sans-serif', fontWeight:900, letterSpacing:scene.kind==='final'?10:5, fontSize:scene.kind==='final'?104:78, color:C.white, textShadow:'0 5px 35px rgba(0,0,0,.8)'}}>{scene.title}</div>
        <div style={{marginTop:28, fontFamily:'Arial, sans-serif', fontWeight:600, letterSpacing:4, fontSize:27, color:C.cyan}}>{scene.sub}</div>
        {scene.kind==='final' && <div style={{margin:'42px auto 0', width:130, height:5, borderRadius:10, background:C.blue, boxShadow:'0 0 24px #55c8ff'}}/>}
      </div>
      <div style={{position:'absolute', top:70, left:70, right:70, display:'flex', justifyContent:'space-between', color:'rgba(190,225,245,.55)', fontSize:18, letterSpacing:4}}>
        <span>NOVA / FUTURE INTELLIGENCE</span><span>2026</span>
      </div>
      <div style={{position:'absolute', bottom:90, left:70, right:70, height:2, background:'rgba(150,210,255,.16)'}}>
        <div style={{height:'100%', width:`${Math.min(100,local/scene.dur*100)}%`, background:C.blue, boxShadow:'0 0 12px #55c8ff'}}/>
      </div>
    </AbsoluteFill>
  );
};

export const NovaAI: React.FC = () => (
  <AbsoluteFill style={{background:C.bg}}>
    {scenes.map((scene)=><Sequence key={scene.from} from={scene.from} durationInFrames={scene.dur}><Scene scene={scene}/></Sequence>)}
  </AbsoluteFill>
);