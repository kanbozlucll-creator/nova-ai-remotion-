import React from 'react';
import {Composition} from 'remotion';
import {NovaAI} from './Trailer';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="NovaAI"
    component={NovaAI}
    durationInFrames={1200}
    fps={30}
    width={1080}
    height={1920}
  />
);