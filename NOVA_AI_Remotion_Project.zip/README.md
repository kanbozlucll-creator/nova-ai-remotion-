# NOVA AI — Remotion vertical trailer

40 saniyelik, 9:16 dikey teknoloji reklamı için Remotion başlangıç projesi.

## Özellikler
- 1080 × 1920, 30 FPS, 1200 kare (40 saniye)
- Hollywood fragmanı hissi veren koyu sinematik görünüm
- Animasyonlu ışık küresi, parçacıklar, arayüz halkaları ve dijital dünya
- Türkçe sloganlar ve sahne zamanlaması
- Türkçe erkek seslendirme metni: `public/VOICEOVER.txt`

## Kurulum
Node.js 18+ önerilir.

```bash
npm install
npm run start
```

## MP4 render
```bash
npm run render
```

Çıktı: `public/nova-ai-trailer.mp4`

## Seslendirme ve müzik
Bu proje görsel fragman animasyonunu ve seslendirme metnini içerir; hazır bir ses kaydı veya lisanslı müzik dosyası içermez.
Derin erkek seslendirmesini `public/voiceover.mp3`, müziği `public/music.mp3` olarak ekleyip `Trailer.tsx` içindeki ana `AbsoluteFill` içine aşağıdaki satırları ekleyebilirsiniz:

```tsx
<Audio src={staticFile('voiceover.mp3')} />
<Audio src={staticFile('music.mp3')} />
```

Ses dosyalarını Remotion projesine eklerken kullanım lisanslarını kontrol edin.
